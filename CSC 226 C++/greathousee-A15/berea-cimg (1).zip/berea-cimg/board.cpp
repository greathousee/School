/*  board.cpp

    This program creates the image of a small playing board.
    Created as CImg tutorial on simple bmp pixelwise image manipulation
    for use in CSC 226 at Berea College by Dr. Jan Pearce

    For use in Windows applications using the IDE Code::Blocks, do the following:
    Under Project->Build Options->Linker Settings->Link Libraries: add gdi32
*/

#include "CImg.h"
#include <iostream>
  using namespace cimg_library;
  using namespace std;

void displaydirections();

int main () {

   const int boardsize=3;

   int x, y, r, g, b;

   // Use the CImg constructor to define a color image called myboard
   // Note that z=1 means our board is 2D and c=3 gives us 3 color channels RGB
   CImg<unsigned int>myboard(boardsize,boardsize,1,3);// x, y, z, c

   cout << "\nThe following are the color channel values:\n\n"<< endl;

   //These loops manipuate the image at the level of the pixels
   for (y = 0; y<boardsize; y++)
   {
      for (x = 0; x<boardsize; x++)
      {
         myboard(x,y,0)=255; // c=0 is the Red channel
         myboard(x,y,1)=0; // c=1 is the Green channel
         myboard(x,y,2)=0; //c=2 is the Blue Channel

         //Prints the intensities of the color channels for viewing
         cout <<"["<<myboard(x,y,0);
         cout <<","<<myboard(x,y,1);
         cout <<","<<myboard(x,y,2)<< "] ";
      }
      cout <<'\n'<<endl; // improves readability
   }

   displaydirections();

   //Note that the display member function is very powerful!
   //It allows pixel information to show as well as zooming and resizing.
   //However, it has a color "normalization" feature turned on,
   //which will change the color of certain images or even set them to all black.
   //ask me if you want details on why and/or how to turn this off.
   //otherwise just be sure use red, green, or blue for your intial boards.

   myboard.display("Board");

   cout << "\n\n-_-_-_-_-_-_-_-_-_-_-_-_-_-_-\n\n"<<endl;

   cout << "Enter the x y coordinates for your play (separated by a space), remembering" <<endl;
   cout << "that each value must be between 0 and " << boardsize-1 << " inclusive: ";
   cin >> x >> y;

   cout << "\nNow enter the R G B values (separated by spaces), remembering"<<endl;
   cout << "that each channel value must be beween 0 and 255 inclusive: ";
   cin >> r >> g >> b;

   myboard(x,y,0)=r; // set the Red channel to desired value
   myboard(x,y,1)=g; // c=1 is the Green channel
   myboard(x,y,2)=b; //c=2 is the Blue Channel

   displaydirections();
   myboard.display("Board");
}

 void displaydirections()
 /* displays directions allowing interaction with both console and image */
 {
   cout << "\n\n-_-_-_-_-_-_-_-_-_-_-_-_-_-_\n\n";
   cout << "CLOSE YOUR BOARD TO CONTINUE";
   cout << "\n\n-_-_-_-_-_-_-_-_-_-_-_-_-_-_\n";
 }
