#include "timer.h"

timer::timer()
{
    //ctor
}

timer::~timer()
{
    //dtor
}
