#ifndef TIMER_H
#define TIMER_H


class timer
{
    public:
        timer();
        virtual ~timer();
    protected:
    private:
};

#endif // TIMER_H
