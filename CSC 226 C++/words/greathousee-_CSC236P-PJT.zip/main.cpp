#include <iostream>
#include <fstream>
#include <string>
//The following three libraries come from: http://www.cplusplus.com/reference/ctime/clock/
#include <stdio.h>      /* printf */
#include <time.h>       /* clock_t, clock, CLOCKS_PER_SEC */
#include <math.h>       /* sqrt */
#include "features.h"

using namespace std;

int main()
{
    features game;
    return 0;
}
